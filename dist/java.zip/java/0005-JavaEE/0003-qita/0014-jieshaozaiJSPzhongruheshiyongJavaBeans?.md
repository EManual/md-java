在JSP中使用JavaBean常用的动作有：
```java  
1）<jsp:useBean />：用来创建和查找bean对象；
2）<jsp:setProperty />：用来设置bean的属性，即调用其setXxx()方法；
3）<jsp:getProperty />：用来获得bean的属性，即调用其getXxx()方法。
```
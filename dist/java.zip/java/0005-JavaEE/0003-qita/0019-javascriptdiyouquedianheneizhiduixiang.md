1）优点：简单易用，与Java有类似的语法，可以使用任何文本编辑工具编写，只需要浏览器就可执行程序，并且事先不用编译，逐行执行，无需进行严格的变量声明，而且内置大量现成对象，编写少量程序可以完成目标；
2）缺点：不适合开发大型应用程序；
3）Javascript有11种内置对象： Array、String、Date、Math、Boolean、Number、Function、Global、Error、RegExp、Object。